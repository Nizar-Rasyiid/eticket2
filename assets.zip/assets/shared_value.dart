List listProduct = [
  {
    "name":"Pizza",
    "price":50000,
    "rating":4.8,
    "time":"15 - 20 min",
    "images":"https://image.freepik.com/free-photo/side-view-pizza-with-chopped-pepper-board-cookware_176474-3183.jpg"
  },
  {
    "name":"Hamburger",
    "price":20000,
    "rating":4.5,
    "time":"10 - 20 min",
    "images":"https://image.freepik.com/free-photo/big-sandwich-hamburger-burger-with-beef-red-onion-tomato-fried-bacon_2829-5398.jpg"
  },
  {
    "name":"Kebab",
    "price":15000,
    "rating":5,
    "time":"10 - 15 min",
    "images":"https://image.freepik.com/free-photo/side-view-shawarma-with-fried-potatoes-board-cookware_176474-3215.jpg"
  },
  {
    "name":"Mie Ayam",
    "price":20000,
    "rating":4.3,
    "time":"5 - 10 min",
    "images":"https://image.freepik.com/free-photo/chopsticks-pick-up-tasty-noodles-with-smoke-dark-background-ramen-white-bowl_79161-418.jpg"
  },
  {
    "name":"Coffe Boba",
    "price":30000,
    "rating":4.9,
    "time":"10 - 20 min",
    "images":"https://image.freepik.com/free-vector/boba-tea-element-with-splashing-milk-glass-cup-black-background-3d-illustration_317396-160.jpg"
  },
  {
    "name":"Nasi Goreng",
    "price":20000,
    "rating":4.2,
    "time":"10 - 20 min",
    "images":"https://image.freepik.com/free-photo/fried-rice-nasi-goreng-indonesian-dish_262958-1512.jpg"
  },
];

List listCart = [
  {
    "name":"Pizza",
    "price":150000,
    "qty":2,
    "images":"https://image.freepik.com/free-photo/side-view-pizza-with-chopped-pepper-board-cookware_176474-3183.jpg"
  },
  {
    "name":"Mie Ayam",
    "price":20000,
    "qty":1,
    "images":"https://image.freepik.com/free-photo/chopsticks-pick-up-tasty-noodles-with-smoke-dark-background-ramen-white-bowl_79161-418.jpg"
  },
  {
    "name":"Coffe Boba",
    "price":30000,
    "qty":1,
    "images":"https://image.freepik.com/free-vector/boba-tea-element-with-splashing-milk-glass-cup-black-background-3d-illustration_317396-160.jpg"
  },
];